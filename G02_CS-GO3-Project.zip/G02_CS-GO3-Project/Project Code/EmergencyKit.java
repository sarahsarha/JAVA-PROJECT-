import java.util.ArrayList;

/**
 * EmergencyKit — Concrete Class implementing Inventory
 */
public class EmergencyKit implements Inventory {

    // ─── Attributes ───────────────────────────────────────────
    private ArrayList<String> items;
    private int waterSupplyDays;
    private boolean hasFirstAid;

    // ─── Constructor ──────────────────────────────────────────
    public EmergencyKit() {
        this.items = new ArrayList<>();
        this.waterSupplyDays = 0;
        this.hasFirstAid = false;
    }

    // ─── Method Overriding ────────────────────────────────────
    @Override
    public void addItem(String item) {
        if (item == null || item.trim().isEmpty()) return;

        String cleanItem = item.trim().toLowerCase();

        if (!items.contains(cleanItem)) {
            items.add(cleanItem);
            System.out.println("🎒 [KIT] Added item: " + item);
        }

        // Update flags
        if (cleanItem.contains("first aid") || cleanItem.contains("medical kit")) {
            this.hasFirstAid = true;
        }
    }

    // ─── Method Overloading ───────────────────────────────────
    public void addItem(String item, int daysRation) {
        if (item == null || item.trim().isEmpty()) return;

        String cleanItem = item.trim().toLowerCase();

        if (cleanItem.equals("water")) {
            this.waterSupplyDays += daysRation;
            System.out.println("💧 [KIT] Added " + daysRation + " day(s) water");

            if (!items.contains("water")) {
                items.add("water");
            }
        } else {
            if (!items.contains(cleanItem)) {
                items.add(cleanItem);
            }
        }
    }

    // ─── ✅ UPDATED COMPLETENESS LOGIC ────────────────────────
    @Override
    public boolean checkCompleteness() {

        boolean hasWaterMinimum = (waterSupplyDays >= 3);
        boolean hasFlashlight = items.contains("flashlight");

        return hasFirstAid && hasWaterMinimum && hasFlashlight;
    }

    // ─── Scenario Validation ─────────────────────────────────
    public void ventureIntoScenario(String disasterType) throws IncompleteKitException {

        if (!checkCompleteness()) {

            int missingWater = Math.max(0, 3 - waterSupplyDays);

            String reason = "🚨 Kit incomplete!\n"
                    + (!hasFirstAid ? "- Missing First Aid\n" : "")
                    + (!items.contains("flashlight") ? "- Missing Flashlight\n" : "")
                    + (missingWater > 0 ? "- Need " + missingWater + " more day(s) of water\n" : "");

            throw new IncompleteKitException(reason);
        }
    }

    // ─── Status Display ──────────────────────────────────────
    public void showKitStatus() {
        System.out.println("\n📦 KIT STATUS");
        System.out.println("Items: " + items);
        System.out.println("Water: " + waterSupplyDays + " days");
        System.out.println("First Aid: " + (hasFirstAid ? "YES" : "NO"));
        System.out.println("Flashlight: " + (items.contains("flashlight") ? "YES" : "NO"));
        System.out.println(checkCompleteness() ? "✅ READY" : "❌ NOT READY");
    }

    // ─── Getters ─────────────────────────────────────────────
    public ArrayList<String> getItems() {
        return items;
    }

    public int getWaterSupplyDays() {
        return waterSupplyDays;
    }

    public boolean isHasFirstAid() {
        return hasFirstAid;
    }

    // ✅ NEW METHOD for GUI
    public boolean isHasFlashlight() {
        return items.contains("flashlight");
    }
}